package com.venunair.warden.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.venunair.warden.R

/**
 * DM Sans — the headline/title face. Regular (400), Medium (500),
 * SemiBold (600), Bold (700) bundled as TTF in res/font. Used for
 * display, headline, and title roles where a distinctive face gives the
 * app its personality. Body and label roles stay on the system default
 * (Roboto) for maximum readability at small sizes.
 */
val DmSansFamily = FontFamily(
    Font(R.font.dm_sans_400, FontWeight.Normal),
    Font(R.font.dm_sans_500, FontWeight.Medium),
    Font(R.font.dm_sans_600, FontWeight.SemiBold),
    Font(R.font.dm_sans_700, FontWeight.Bold),
)

/**
 * Warden's type scale. Material3 defines 15 text styles across 5 roles:
 *   display (3) → headline (3) → title (3) → body (3) → label (3)
 *
 * DM Sans handles the top three roles (display, headline, title) — these
 * are the "brand voice" sizes where a distinct typeface has the most
 * impact. Body and label stay on the platform default (Roboto/system) for
 * comfortable long-reading and small-label legibility.
 */
val WardenTypography = Typography(
    // Display — splash, onboarding, large empty-state headlines
    displayLarge = TextStyle(
        fontFamily = DmSansFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 57.sp,
        lineHeight = 64.sp,
        letterSpacing = (-0.25).sp,
    ),
    displayMedium = TextStyle(
        fontFamily = DmSansFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 45.sp,
        lineHeight = 52.sp,
        letterSpacing = 0.sp,
    ),
    displaySmall = TextStyle(
        fontFamily = DmSansFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 36.sp,
        lineHeight = 44.sp,
        letterSpacing = 0.sp,
    ),

    // Headline — section headers, summary cards, TCO totals
    headlineLarge = TextStyle(
        fontFamily = DmSansFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 32.sp,
        lineHeight = 40.sp,
        letterSpacing = 0.sp,
    ),
    headlineMedium = TextStyle(
        fontFamily = DmSansFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 28.sp,
        lineHeight = 36.sp,
        letterSpacing = 0.sp,
    ),
    headlineSmall = TextStyle(
        fontFamily = DmSansFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 24.sp,
        lineHeight = 32.sp,
        letterSpacing = 0.sp,
    ),

    // Title — TopAppBar titles, card headers, dialog titles
    titleLarge = TextStyle(
        fontFamily = DmSansFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp,
        lineHeight = 28.sp,
        letterSpacing = 0.sp,
    ),
    titleMedium = TextStyle(
        fontFamily = DmSansFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.15.sp,
    ),
    titleSmall = TextStyle(
        fontFamily = DmSansFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.1.sp,
    ),

    // Body — stays on system default (Roboto) for readability
    // These are intentionally not set to DmSansFamily; the Typography
    // constructor fills them with the platform default.

    // Label — stays on system default (Roboto) for small-size legibility
    // Same rationale as body — system default at label sizes is optimal.
)
